
Taken from lib/crypto/* of samba-4.5.8.tar.gz.

/TR 2018-11-15
